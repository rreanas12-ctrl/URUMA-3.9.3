# URUMA Android 3.9.1

This project wraps the existing `URUMA 3.9.1.html` interface in a native Android app.

## What is included now
- Existing URUMA HTML UI kept as the app screen.
- Native Android `SpeechRecognizer` running in a microphone foreground service.
- Wake phrase detection for `Wake up Uruma` and existing Arabic variants.
- After wake, native recognition switches to `ar-MA` and forwards recognized text to the URUMA web UI.
- Android Text-to-Speech greeting when URUMA wakes.
- Foreground-service notification so Android can keep the microphone service alive under its background rules.

## Important
The current HTML still contains the Groq API call from the original project. For a production app, move the API key and AI request to a backend rather than shipping the key inside the APK.

## Build
Open this folder in Android Studio, let Gradle sync, then build the debug APK.

Required runtime permissions:
- Microphone
- Notifications (Android 13+)

Android may restrict long-running microphone use depending on battery/background settings. The next phase should add native phone actions (apps, YouTube, calls, messages) behind explicit permissions/roles.
