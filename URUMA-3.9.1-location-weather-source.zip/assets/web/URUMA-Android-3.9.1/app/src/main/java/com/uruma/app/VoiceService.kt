package com.uruma.app

import android.app.*
import android.content.*
import android.os.*
import android.speech.*
import android.speech.tts.TextToSpeech
import androidx.core.app.NotificationCompat
import java.util.*

class VoiceService : Service(), TextToSpeech.OnInitListener {
    private val channelId = "uruma_voice"
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var awake = false
    private var restarting = false
    private var currentLanguage = "en-US"

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(391, notification("URUMA is ready — say Wake up Uruma"))
        tts = TextToSpeech(this, this)
        startRecognition(800)
    }

    private fun createChannel() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(channelId, "URUMA Voice", NotificationManager.IMPORTANCE_LOW))
    }

    private fun notification(text: String): Notification =
        NotificationCompat.Builder(this, channelId)
            .setContentTitle("URUMA")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()

    private fun startRecognition(delay: Long = 0) {
        if (restarting) return
        restarting = true
        Handler(Looper.getMainLooper()).postDelayed({
            restarting = false
            if (!SpeechRecognizer.isRecognitionAvailable(this)) return@postDelayed
            recognizer?.destroy()
            recognizer = SpeechRecognizer.createSpeechRecognizer(this)
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
                override fun onError(error: Int) { startRecognition(500) }
                override fun onResults(results: Bundle?) {
                    val list = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: return
                    val text = list.firstOrNull()?.trim().orEmpty()
                    if (text.isNotEmpty()) handleText(text)
                    startRecognition(250)
                }
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, currentLanguage)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            }
            try { recognizer?.startListening(intent) } catch (_: Exception) { startRecognition(1200) }
        }, delay)
    }

    private fun normalized(s: String) = s.lowercase(Locale.ROOT).replace(Regex("[.,!?؟،]"), "").replace(Regex("\\s+"), " ").trim()

    private fun isWake(text: String): Boolean {
        val t = normalized(text)
        return t.contains("wake up uruma") || t.contains("wake up aroma") ||
            t.contains("ويك اب ايروما") || t.contains("ويك أب ايروما") ||
            t.contains("ويكاب ايروما") || t.contains("استيقظ ايروما") ||
            t.contains("استيقظ يا ايروما") || t.contains("ايروما استيقظ")
    }

    private fun isSleep(text: String): Boolean {
        val t = normalized(text)
        return t.contains("uruma good night") || t.contains("uruma goodnight") ||
            t.contains("ايروما غود نايت") || t.contains("ايروما تصبح على خير") ||
            t.contains("تصبح على خير ايروما") || t.contains("نام ايروما")
    }

    private fun handleText(text: String) {
        if (isWake(text)) {
            if (!awake) {
                awake = true
                currentLanguage = "ar-MA"
                broadcast(text)
                speak("مرحبا، أنا أوروما. أنا مستعد.")
                updateNotification("URUMA awake — listening")
            } else broadcast(text)
            return
        }
        if (isSleep(text)) {
            broadcast(text)
            awake = false
            currentLanguage = "en-US"
            updateNotification("URUMA is ready — say Wake up Uruma")
            return
        }
        if (awake) broadcast(text)
    }

    private fun broadcast(text: String) {
        sendBroadcast(Intent("com.uruma.app.VOICE_TEXT").setPackage(packageName).putExtra("text", text))
    }

    private fun updateNotification(text: String) {
        getSystemService(NotificationManager::class.java).notify(391, notification(text))
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "URUMA")
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("ar", "MA")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        recognizer?.destroy()
        recognizer = null
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
