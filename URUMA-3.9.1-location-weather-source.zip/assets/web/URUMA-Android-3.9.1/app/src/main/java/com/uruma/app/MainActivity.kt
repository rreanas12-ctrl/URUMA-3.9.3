package com.uruma.app

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.location.Geocoder
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import org.json.JSONObject
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val text = intent?.getStringExtra("text") ?: return
            webView.post {
                val safe = org.json.JSONObject.quote(text)
                webView.evaluateJavascript("window.onNativeVoiceText && window.onNativeVoiceText($safe);", null)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.mediaPlaybackRequiresUserGesture = false
        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = WebViewClient()
        webView.addJavascriptInterface(AndroidBridge(this), "AndroidBridge")
        webView.loadUrl("file:///android_asset/uruma.html")

        requestPermissionsIfNeeded()
        startVoiceService()
        requestLocation()
    }

    private fun requestPermissionsIfNeeded() {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.RECORD_AUDIO)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.ACCESS_COARSE_LOCATION)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (android.os.Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) needed.add(Manifest.permission.POST_NOTIFICATIONS)
        if (needed.isNotEmpty()) ActivityCompat.requestPermissions(this, needed.toTypedArray(), 1001)
    }

    private fun requestLocation() {
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
        var delivered = false
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (delivered) return
                delivered = true
                sendLocationToWeb(location)
                try { lm.removeUpdates(this) } catch (_: Exception) {}
            }
        }
        try {
            val last = providers.mapNotNull { p ->
                try { if (lm.isProviderEnabled(p)) lm.getLastKnownLocation(p) else null } catch (_: Exception) { null }
            }.maxByOrNull { it.time }
            if (last != null && System.currentTimeMillis() - last.time < 15 * 60 * 1000L) {
                delivered = true
                sendLocationToWeb(last)
                return
            }
            for (p in providers) {
                try { if (lm.isProviderEnabled(p)) lm.requestLocationUpdates(p, 1000L, 10f, listener, mainLooper) } catch (_: Exception) {}
            }
        } catch (_: SecurityException) {}
    }

    private fun sendLocationToWeb(location: Location) {
        val lat = location.latitude
        val lon = location.longitude
        Thread {
            var city = "موقعك الحالي"
            try {
                val geocoder = Geocoder(this, Locale("ar", "MA"))
                @Suppress("DEPRECATION")
                val addresses = geocoder.getFromLocation(lat, lon, 1)
                if (!addresses.isNullOrEmpty()) {
                    city = addresses[0].locality ?: addresses[0].subAdminArea ?: addresses[0].adminArea ?: city
                }
            } catch (_: Exception) {}

            var weather = "--°C"
            try {
                val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m&temperature_unit=celsius")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 8000
                    readTimeout = 8000
                }
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val json = JSONObject(body)
                val temp = json.getJSONObject("current").getDouble("temperature_2m")
                weather = String.format(Locale.US, "%.0f°C", temp)
            } catch (_: Exception) {}

            runOnUiThread {
                val payload = JSONObject().apply {
                    put("lat", lat)
                    put("lon", lon)
                    put("city", city)
                    put("weather", weather)
                }.toString()
                webView.evaluateJavascript("window.onNativeLocation && window.onNativeLocation(${JSONObject.quote(payload)});", null)
            }
        }.start()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001) requestLocation()
    }

    private fun startVoiceService() {
        val intent = Intent(this, VoiceService::class.java)
        ContextCompat.startForegroundService(this, intent)
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter("com.uruma.app.VOICE_TEXT")
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onStop() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        super.onStop()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}

class AndroidBridge(private val context: Context) {
    @JavascriptInterface
    fun startVoiceService() {
        ContextCompat.startForegroundService(context, Intent(context, VoiceService::class.java))
    }
    @JavascriptInterface
    fun stopVoiceService() {
        context.stopService(Intent(context, VoiceService::class.java))
    }
    @JavascriptInterface
    fun requestLocation() {
        (context as? MainActivity)?.requestLocation()
    }
}
